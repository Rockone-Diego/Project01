

#!/bin/bash

# Fonction 
F_sales() {
    echo "$(date)" >> /home/ubuntu/exam_MAHDI/exam_bash/sales.txt
    for card in rtx3060 rtx3070 rtx3080 rtx3090 rx6700
    do
        sales=$(curl -s "http://0.0.0.0:5000/$card")
        echo "$card:$sales" >> /home/ubuntu/exam_MAHDI/exam_bash/sales.txt
    done
}

# Boucle qui  exécuter la fonction F_sales chaque minute
F_sales
