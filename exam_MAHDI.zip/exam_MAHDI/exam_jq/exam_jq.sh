#!/bin/bash

# Q 1
echo "Affichez le nombre d'attributs par document ainsi que l'attribut name. Combien y a-t-il d'attribut par document ? N'affichez que les 12 premières lignes avec la commande head (notebook #2)."

jq '.[] | {name, count: length}' people.json | head -n 12


echo -e "\n---------------------------------\n"

# Q 2 
echo  "Combien y a-t-il de valeur "unknown" pour l'attribut "birth_year" ? Utilisez la commande tail afin d'isoler la réponse."

jq '[.[] | select(.birth_year == "unknown")] | length' people.json

echo -e "\n---------------------------------\n"


# Q 3 
echo  "Affichez la date de création de chaque personnage et son nom. La date de création doit être de cette forme : l'année, le mois et le jour. N'affichez que les 10 premières lignes."

jq '.[] | {name, created: (.created | split("T")[0])}' people.json | head -n 10


echo -e "\n---------------------------------\n"





# Q 4  
echo "Certains personnages sont nés en même temps. Retrouvez toutes les pairs d'ids (2 ids) des personnages nés en même temps."

jq 'group_by(.birth_year) | map(select(length == 2)) | .[] | {ids: [.[] | .id]}' people.json



echo -e "\n---------------------------------\n"



# Q 5
echo "Renvoyez le numéro du premier film (de la liste) dans lequel chaque personnage a été vu suivi du nom du personnage. N'affichez que les 10 premières lignes."

jq '.[] | {first_film: .films[0], name: .name}' people.json | head -n 10



echo -e "\n---------------------------------\n"
